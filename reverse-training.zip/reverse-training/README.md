# 🏠 Reverse Mortgage Mastery

Interactive training quiz hub for Luminate Bank's 5-Week Reverse Sales Course.

## 🚀 Live Demo

Visit: `https://yourusername.github.io/reverse-training/`

## 📁 Project Structure

```
reverse-training/
├── index.html          # Main HTML file
├── css/
│   └── styles.css      # Stylesheet
├── js/
│   └── app.js          # React application
├── assets/
│   └── images/         # Image assets (if needed)
└── README.md           # This file
```

## ✨ Features

- **5 Weekly Modules** - Each week has its own themed quiz
- **Multiple Question Types** - Myth/Fact, Multiple Choice, Scenarios
- **Progress Tracking** - Scores saved locally in browser
- **Gamification** - Best scores, completion tracking, achievements
- **Mobile Responsive** - Works on desktop, tablet, and phone

## 📅 Course Curriculum

| Week | Topic | Focus |
|------|-------|-------|
| 1 | 🔄 Reframing Reverse | Myths, language, positioning |
| 2 | 💎 Mining Your Database | CRM, triggers, 30-second pitch |
| 3 | 💬 Messaging That Works | CARE framework, 3R Value Story |
| 4 | 🤖 Marketing in the AI Era | ChatGPT, SimpleApp, Scenario Desk |
| 5 | 🚀 Your Growth Plan | 90-day action items, partnerships |

## 🛠️ Setup for GitHub Pages

1. Create a new repository on GitHub
2. Upload all files maintaining the folder structure
3. Go to **Settings** → **Pages**
4. Set Source to **Deploy from branch** → **main** → **/ (root)**
5. Save and wait ~60 seconds for deployment

## 🎨 Brand Colors

- Navy: `#0D1B3E`
- Pink: `#E683AC`
- Cyan: `#7DD3FC`
- Green: `#4ADE80`
- Gold: `#FBBF24`
- Purple: `#A78BFA`
- Orange: `#FB923C`

## 📊 Future Enhancements

- [ ] Power Automate integration for result tracking
- [ ] Final Exam combining all weeks
- [ ] Team leaderboard
- [ ] Certificate generation

---

**Luminate Bank** | Retirement Mortgage Training Program
